print('suraj')
print('python')
