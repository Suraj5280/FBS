a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

a = a + b
b = a - b
a = a - b

print("After swapping:")
print("First number =", a)
print("Second number =", b)


#same as the Q8 but without using temp funciton