a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

temp = a
a = b
b = temp

print("After swapping:")
print("First number =", a)
print("Second number =", b)

#changing a to b and b to a 