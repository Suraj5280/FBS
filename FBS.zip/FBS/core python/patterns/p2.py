for i in range(1,6):
    for j in range(1,6):
        print(i,end = ' ')
    print()

    #print same numbers in row