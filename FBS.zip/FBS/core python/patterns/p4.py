for i in range(1,6):
    for j in range(1,7-i):
        print('*',end = ' ')
    print()

    #print stars in trangle shape but revers order